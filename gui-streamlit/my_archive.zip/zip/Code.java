import org.apache.jena.rdf.model.*;
import org.apache.jena.util.FileManager;

import java.util.HashMap;
import java.util.Map;

public class Code {
    public static void main(String[] args) {
        String filePath = "./data/uploads/books.ttl";
        Model model = ModelFactory.createDefaultModel();

        // Read the RDF file, specifying the Turtle format
        FileManager.get().readModel(model, filePath, null, "TURTLE");

        int predicateCount = 0;
        Map<String, Integer> classCountMap = new HashMap<>();

        // Iterate over the statements in the model
        StmtIterator iterator = model.listStatements();
        while (iterator.hasNext()) {
            Statement stmt = iterator.next();

            // Count predicates
            predicateCount++;

            // Process the object if it's a URI resource
            if (stmt.getObject().isURIResource()) {
                Resource object = stmt.getObject().asResource();
                String classUri = object.getURI();
                classCountMap.put(classUri, classCountMap.getOrDefault(classUri, 0) + 1);
            }
        }

        // Prepare the result
        Map<String, Integer> result = new HashMap<>();
        result.put("predicateCount", predicateCount);
        result.put("classCount", classCountMap.size());

        // Output the result
        System.out.println(result);
    }
}