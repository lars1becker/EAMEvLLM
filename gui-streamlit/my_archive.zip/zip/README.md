
# My App
docker and docker-compose needs to be installed

In terminal run the following command:
docker-compose up --build

    