
# My App
docker and docker-compose needs to be installed

In terminal run the following command:
docker-compose up --build

The API enpoint is available at:
http://localhost:9000/process?path=file://path/to/file

    