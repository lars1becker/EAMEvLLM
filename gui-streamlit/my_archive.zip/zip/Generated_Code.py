from PIL import Image
import os

image_path = './data/uploads/Lars.png'
with Image.open(image_path) as img:
    width, height = img.size
    aspect_ratio = width / height
    file_type = os.path.splitext(os.path.basename(image_path))[1][1:]
    result = {
        'aspect_ratio': aspect_ratio,
        'dimensions': (width, height),
        'file_type': file_type
    }

print(result)